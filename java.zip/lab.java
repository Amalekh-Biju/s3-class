public class lab {
    
}
//write a java code that shows the usage of try, catch, and finally block for arithmetic exception and array index out of bounds exception.
//wrtie a java code that shows the usage of throw and throws for class not found exception and handle it using try and catch block.
//write a java code for developing a basic calculator. 
//the calculator should be able to perform basic operations like addition, subtraction, multiplication, and division operations on two numbers.
//implement exception handling such that the program handles the following scenarios:
//input mismatch exception ; if the user enters non-numeric values for the numbers catch the exception and display an error message.
//divide by zero exception ; if the user tries to divide a number by zero catch the exception and display an error message.
//invalid operator exception ; if the user enters an invalid operator throw an illegal argument exception and display an error message.
